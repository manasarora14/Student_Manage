﻿using Microsoft.AspNetCore.Identity;

namespace StudentApi.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}
